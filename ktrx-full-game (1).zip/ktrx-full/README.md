# KTRX — Katihar Battle Royale

A playable full-stack prototype for the KTRX concept.

## What is included
- Cinematic lobby UI based on the provided visual reference
- Solo-only mode
- Profile / level / XP UI
- Weapons, character, inventory, battle pass and store screens
- Loadout: primary, secondary, melee, frag, smoke, med kit
- Socket.IO real-time matchmaking
- 30-player match target
- 25-minute match timer architecture
- Server-authoritative virtual HP/armor/combat
- Virtual weapon range and damage validation
- Shrinking zone damage
- Match HUD, alive counter, kill events
- Keyboard movement (W/A/S/D) in prototype match
- Persistent-ready structure for later Supabase auth/profile/database work

## Run
1. Install Node.js 20+.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.
6. Open multiple browser tabs/windows to test Socket.IO multiplayer.

## Asset
`public/assets/lobby-bg.jpg` is a cropped version of the visual reference supplied in the conversation and is used only as a temporary visual placeholder. Replace it with original KTRX artwork before public release.

## Important
This is a functional prototype, not a production 30-player location game. Real GPS, authentication, database persistence, anti-cheat, safe-zone geofencing, production matchmaking, mobile PWA behavior, audio assets and deployment still need to be integrated before public launch.
