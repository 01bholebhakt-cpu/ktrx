const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));

const queue = [];
const matches = new Map();
let matchSeq = 1000;

function makeMatch() {
  const id = `KTRX-${++matchSeq}`;
  const match = {
    id,
    state: 'lobby',
    players: new Map(),
    startedAt: null,
    endsAt: null,
    zone: { x: 0.5, y: 0.5, radius: 0.42 },
    events: []
  };
  matches.set(id, match);
  return match;
}

function removeFromQueue(id) {
  const i = queue.indexOf(id);
  if (i >= 0) queue.splice(i, 1);
}

function broadcastMatch(match) {
  io.to(match.id).emit('matchState', {
    id: match.id,
    state: match.state,
    startedAt: match.startedAt,
    endsAt: match.endsAt,
    zone: match.zone,
    players: [...match.players.values()].map(p => ({
      id:p.id, name:p.name, x:p.x, y:p.y, hp:p.hp, armor:p.armor,
      alive:p.alive, kills:p.kills, weapon:p.weapon
    }))
  });
}

function fillMatch() {
  while (queue.length) {
    const ids = queue.splice(0, 30);
    if (!ids.length) return;
    const match = makeMatch();
    for (const id of ids) {
      const s = io.sockets.sockets.get(id);
      if (!s) continue;
      const p = {
        id:s.id,
        name:s.data.name || `KTRX_${s.id.slice(0,5).toUpperCase()}`,
        x:0.2 + Math.random()*0.6,
        y:0.2 + Math.random()*0.6,
        hp:100, armor:50, alive:true, kills:0, weapon:'KX-416'
      };
      match.players.set(s.id,p);
      s.data.matchId=match.id;
      s.join(match.id);
      s.emit('matchFound',{id:match.id, players:match.players.size});
    }
    if (match.players.size >= 1) startMatch(match);
  }
}

function startMatch(match) {
  match.state='live';
  match.startedAt=Date.now();
  match.endsAt=Date.now()+25*60*1000;
  match.events.push({type:'system',text:'DEPLOYMENT COMPLETE'});
  broadcastMatch(match);
}

io.on('connection', socket => {
  socket.data.name = `KTRX_${socket.id.slice(0,5).toUpperCase()}`;

  socket.on('profile', data => {
    if (data && typeof data.name === 'string') {
      socket.data.name = data.name.slice(0,18) || socket.data.name;
    }
  });

  socket.on('queue', () => {
    if (socket.data.matchId) return;
    if (!queue.includes(socket.id)) queue.push(socket.id);
    socket.emit('queueState',{queued:queue.length, target:30});
    fillMatch();
  });

  socket.on('cancelQueue', () => {
    removeFromQueue(socket.id);
    socket.emit('queueState',{queued:queue.length,target:30});
  });

  socket.on('move', data => {
    const match=matches.get(socket.data.matchId);
    const p=match?.players.get(socket.id);
    if (!p || !p.alive || match.state!=='live') return;
    const x=Math.max(0,Math.min(1,Number(data.x)));
    const y=Math.max(0,Math.min(1,Number(data.y)));
    if (Number.isFinite(x)&&Number.isFinite(y)) { p.x=x;p.y=y; }
    broadcastMatch(match);
  });

  socket.on('fire', data => {
    const match=matches.get(socket.data.matchId);
    const attacker=match?.players.get(socket.id);
    if (!match || !attacker || !attacker.alive || match.state!=='live') return;
    const target=match.players.get(data?.targetId);
    if (!target || !target.alive || target.id===attacker.id) return;
    const dx=target.x-attacker.x, dy=target.y-attacker.y;
    const distance=Math.sqrt(dx*dx+dy*dy);
    const range = data?.weapon==='KX-9' ? 0.18 : data?.weapon==='KX-DMR' ? 0.48 : 0.30;
    if (distance>range) return;
    let damage = data?.weapon==='KX-DMR' ? 45 : data?.weapon==='KX-9' ? 22 : 30;
    const absorbed=Math.min(target.armor,Math.floor(damage*.55));
    target.armor-=absorbed;
    target.hp-=damage-absorbed;
    if(target.hp<=0){
      target.hp=0; target.alive=false; attacker.kills++;
      match.events.push({type:'kill',text:`${attacker.name} eliminated ${target.name}`});
    }
    broadcastMatch(match);
  });

  socket.on('leaveMatch',()=>{
    const match=matches.get(socket.data.matchId);
    if(match){ match.players.delete(socket.id); broadcastMatch(match); }
    socket.data.matchId=null;
  });

  socket.on('disconnect',()=>{
    removeFromQueue(socket.id);
    const match=matches.get(socket.data.matchId);
    if(match){ match.players.delete(socket.id); broadcastMatch(match); }
  });
});

setInterval(()=>{
  for(const match of matches.values()){
    if(match.state!=='live') continue;
    const elapsed=(Date.now()-match.startedAt)/(25*60*1000);
    match.zone.radius=Math.max(.08,.42-.34*elapsed);
    for(const p of match.players.values()){
      const dx=p.x-match.zone.x,dy=p.y-match.zone.y;
      if(p.alive && Math.sqrt(dx*dx+dy*dy)>match.zone.radius){
        p.hp=Math.max(0,p.hp-2);
        if(p.hp===0)p.alive=false;
      }
    }
    const alive=[...match.players.values()].filter(p=>p.alive);
    if(alive.length<=1 || Date.now()>=match.endsAt){
      match.state='finished';
      const winner=alive[0];
      io.to(match.id).emit('matchFinished',{winner:winner?winner.name:null,players:[...match.players.values()]});
    } else broadcastMatch(match);
  }
},1000);

server.listen(PORT,()=>console.log(`KTRX server running on http://localhost:${PORT}`));
